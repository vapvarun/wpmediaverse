<?php
/**
 * Tag REST controller.
 *
 * @package WPMediaVerse
 */

namespace WPMediaVerse\REST\Controller;

defined( 'ABSPATH' ) || exit;

use WP_Error;
use WP_REST_Controller;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

/**
 * REST controller for media tags (mvs_tag taxonomy).
 */
class TagController extends WP_REST_Controller {

	/**
	 * REST API namespace.
	 *
	 * @var string
	 */
	protected $namespace = 'mvs/v1';

	/**
	 * Register routes.
	 */
	public function register_routes(): void {
		// PUBLIC_OK on both __return_true callbacks below (GET /tags and
		// GET /tags/cloud): tags are public taxonomy terms — same surface
		// as WP's /wp-json/wp/v2/tags. No PII. Discovery / SEO surface.
		// POST /tags + POST /tags/merge below carry proper permission
		// callbacks. Triaged 2026-05-01 (Item 5).
		// GET /tags — search/autocomplete.
		// POST /tags — create a new tag (any user who can upload media).
		register_rest_route(
			$this->namespace,
			'/tags',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_tags' ),
					'permission_callback' => '__return_true',
					'args'                => array(
						'search'   => array(
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
						),
						'per_page' => array(
							'type'              => 'integer',
							'default'           => 20,
							'minimum'           => 1,
							'maximum'           => 100,
							'sanitize_callback' => 'absint',
						),
						'orderby'  => array(
							'type'    => 'string',
							'default' => 'name',
							'enum'    => array( 'name', 'count' ),
						),
					),
				),
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'create_tag' ),
					'permission_callback' => array( $this, 'create_tag_permissions_check' ),
					'args'                => array(
						'name' => array(
							'type'              => 'string',
							'required'          => true,
							'sanitize_callback' => 'sanitize_text_field',
						),
						'slug' => array(
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_title',
						),
					),
				),
			)
		);

		// GET /tags/cloud — top tags with counts.
		register_rest_route(
			$this->namespace,
			'/tags/cloud',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_cloud' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'limit' => array(
						'type'              => 'integer',
						'default'           => 50,
						'minimum'           => 1,
						'maximum'           => 200,
						'sanitize_callback' => 'absint',
					),
				),
			)
		);

		// POST /tags/merge — merge source tag into target.
		register_rest_route(
			$this->namespace,
			'/tags/merge',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'merge_tags' ),
				'permission_callback' => array( $this, 'admin_check' ),
				'args'                => array(
					'source_id' => array(
						'type'              => 'integer',
						'required'          => true,
						'sanitize_callback' => 'absint',
					),
					'target_id' => array(
						'type'              => 'integer',
						'required'          => true,
						'sanitize_callback' => 'absint',
					),
				),
			)
		);

		// PUT /tags/{id} — rename tag.
		register_rest_route(
			$this->namespace,
			'/tags/(?P<id>[\d]+)',
			array(
				'methods'             => WP_REST_Server::EDITABLE,
				'callback'            => array( $this, 'rename_tag' ),
				'permission_callback' => array( $this, 'admin_check' ),
				'args'                => array(
					'id'   => array(
						'type'              => 'integer',
						'required'          => true,
						'sanitize_callback' => 'absint',
					),
					'name' => array(
						'type'              => 'string',
						'required'          => true,
						'sanitize_callback' => 'sanitize_text_field',
					),
				),
			)
		);

		// DELETE /tags/{id} — delete tag.
		register_rest_route(
			$this->namespace,
			'/tags/(?P<id>[\d]+)',
			array(
				'methods'             => WP_REST_Server::DELETABLE,
				'callback'            => array( $this, 'delete_tag' ),
				'permission_callback' => array( $this, 'admin_check' ),
				'args'                => array(
					'id' => array(
						'type'              => 'integer',
						'required'          => true,
						'sanitize_callback' => 'absint',
					),
				),
			)
		);
	}

	/**
	 * Get tags with optional search filter.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public function get_tags( $request ) {
		$args = array(
			'taxonomy'   => 'mvs_tag',
			'hide_empty' => false,
			'number'     => (int) $request->get_param( 'per_page' ),
			'orderby'    => $request->get_param( 'orderby' ),
			'order'      => 'count' === $request->get_param( 'orderby' ) ? 'DESC' : 'ASC',
		);

		$search = $request->get_param( 'search' );
		if ( $search ) {
			$args['search'] = $search;
		}

		$terms = get_terms( $args );

		if ( is_wp_error( $terms ) ) {
			return rest_ensure_response( array() );
		}

		$data = array();
		foreach ( $terms as $term ) {
			$data[] = $this->format_term( $term );
		}

		return rest_ensure_response( $data );
	}

	/**
	 * Get tag cloud (top tags by count).
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public function get_cloud( $request ) {
		$limit = (int) $request->get_param( 'limit' );

		$terms = get_terms(
			array(
				'taxonomy'   => 'mvs_tag',
				'hide_empty' => true,
				'number'     => $limit,
				'orderby'    => 'count',
				'order'      => 'DESC',
			)
		);

		if ( is_wp_error( $terms ) ) {
			return rest_ensure_response( array() );
		}

		$data = array();
		foreach ( $terms as $term ) {
			$data[] = $this->format_term( $term );
		}

		return rest_ensure_response( $data );
	}

	/**
	 * Merge source tag into target tag.
	 *
	 * Reassigns all posts from source to target, then deletes source.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function merge_tags( $request ) {
		$source_id = $request->get_param( 'source_id' );
		$target_id = $request->get_param( 'target_id' );

		if ( $source_id === $target_id ) {
			return new WP_Error( 'mvs_same_tag', __( 'Source and target tags must be different.', 'wpmediaverse' ), array( 'status' => 400 ) );
		}

		$source = get_term( $source_id, 'mvs_tag' );
		$target = get_term( $target_id, 'mvs_tag' );

		if ( ! $source || is_wp_error( $source ) ) {
			return new WP_Error( 'mvs_not_found', __( 'Source tag not found.', 'wpmediaverse' ), array( 'status' => 404 ) );
		}

		if ( ! $target || is_wp_error( $target ) ) {
			return new WP_Error( 'mvs_not_found', __( 'Target tag not found.', 'wpmediaverse' ), array( 'status' => 404 ) );
		}

		// Get media IDs with the source tag via term_relationships + mvs_media_index.
		global $wpdb;
		$index_table = $wpdb->prefix . 'mvs_media_index';
		$source_tt   = (int) get_term( $source_id, 'mvs_tag' )->term_taxonomy_id;

		// phpcs:disable WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$media_ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT tr.object_id FROM {$wpdb->term_relationships} tr
				INNER JOIN {$index_table} idx ON idx.media_id = tr.object_id
				WHERE tr.term_taxonomy_id = %d",
				$source_tt
			)
		);
		// phpcs:enable

		$posts        = array();
		$total_merged = 0;

		foreach ( $media_ids as $media_id ) {
			wp_set_object_terms( (int) $media_id, $target_id, 'mvs_tag', true );
			$posts[] = (int) $media_id;
			++$total_merged;
		}

		// Delete source tag.
		wp_delete_term( $source_id, 'mvs_tag' );

		// Sync MediaRepository tags for each affected media item.
		foreach ( $posts as $mid ) {
			$all_terms = get_the_terms( $mid, 'mvs_tag' );
			if ( $all_terms && ! is_wp_error( $all_terms ) ) {
				\WPMediaVerse\Core\Plugin::container()->get( 'media_repository' )->set( $mid, 'tags', wp_json_encode( array_values( wp_list_pluck( $all_terms, 'name' ) ) ) );
			}
		}

		/**
		 * Fires after tags are merged.
		 *
		 * @param int   $source_id Source term ID (deleted).
		 * @param int   $target_id Target term ID (kept).
		 * @param int[] $posts     Post IDs affected.
		 */
		do_action( 'mvs_tags_merged', $source_id, $target_id, $posts );

		return rest_ensure_response(
			array(
				'merged'         => true,
				'target'         => $this->format_term( get_term( $target_id, 'mvs_tag' ) ),
				'posts_affected' => count( $posts ),
			)
		);
	}

	/**
	 * Rename a tag.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function rename_tag( $request ) {
		$term_id = $request->get_param( 'id' );
		$name    = $request->get_param( 'name' );

		$term = get_term( $term_id, 'mvs_tag' );
		if ( ! $term || is_wp_error( $term ) ) {
			return new WP_Error( 'mvs_not_found', __( 'Tag not found.', 'wpmediaverse' ), array( 'status' => 404 ) );
		}

		$result = wp_update_term(
			$term_id,
			'mvs_tag',
			array(
				'name' => $name,
				'slug' => sanitize_title( $name ),
			)
		);

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return rest_ensure_response( $this->format_term( get_term( $term_id, 'mvs_tag' ) ) );
	}

	/**
	 * Delete a tag.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function delete_tag( $request ) {
		$term_id = $request->get_param( 'id' );

		$term = get_term( $term_id, 'mvs_tag' );
		if ( ! $term || is_wp_error( $term ) ) {
			return new WP_Error( 'mvs_not_found', __( 'Tag not found.', 'wpmediaverse' ), array( 'status' => 404 ) );
		}

		$result = wp_delete_term( $term_id, 'mvs_tag' );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		if ( false === $result ) {
			return new WP_Error( 'mvs_delete_failed', __( 'Failed to delete tag.', 'wpmediaverse' ), array( 'status' => 500 ) );
		}

		return rest_ensure_response(
			array(
				'deleted'  => true,
				'previous' => $this->format_term( $term ),
			)
		);
	}

	/**
	 * Format a term for API response.
	 *
	 * @param \WP_Term $term Term object.
	 * @return array
	 */
	private function format_term( $term ): array {
		return array(
			'id'    => $term->term_id,
			'name'  => $term->name,
			'slug'  => $term->slug,
			'count' => $term->count,
		);
	}

	/**
	 * Create a new tag.
	 *
	 * Any logged-in user who can upload media can create tags. Admin-only
	 * operations (rename, merge, delete) remain gated by admin_check().
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function create_tag( $request ) {
		$name = trim( (string) $request->get_param( 'name' ) );
		$slug = (string) $request->get_param( 'slug' );

		if ( '' === $name ) {
			return new WP_Error( 'mvs_invalid_name', __( 'Tag name cannot be empty.', 'wpmediaverse' ), array( 'status' => 400 ) );
		}

		$args = array();
		if ( '' !== $slug ) {
			$args['slug'] = $slug;
		}

		$result = wp_insert_term( $name, 'mvs_tag', $args );

		if ( is_wp_error( $result ) ) {
			if ( 'term_exists' === $result->get_error_code() ) {
				$existing_id = (int) $result->get_error_data();
				$existing    = $existing_id ? get_term( $existing_id, 'mvs_tag' ) : null;
				return new WP_Error(
					'mvs_tag_exists',
					__( 'Tag already exists.', 'wpmediaverse' ),
					array(
						'status'   => 409,
						'existing' => $existing && ! is_wp_error( $existing ) ? $this->format_term( $existing ) : null,
					)
				);
			}
			return $result;
		}

		$term = get_term( $result['term_id'], 'mvs_tag' );
		if ( ! $term || is_wp_error( $term ) ) {
			return new WP_Error( 'mvs_create_failed', __( 'Failed to load created tag.', 'wpmediaverse' ), array( 'status' => 500 ) );
		}

		$response = rest_ensure_response( $this->format_term( $term ) );
		$response->set_status( 201 );
		return $response;
	}

	/**
	 * Permissions: create tag (any user who can upload media).
	 *
	 * Mirrors MediaController::create_item_permissions_check() so the capability
	 * for creating tags stays aligned with the capability for uploading media.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return bool|WP_Error
	 */
	public function create_tag_permissions_check( $request ) {
		if ( ! current_user_can( 'manage_options' ) && ! current_user_can( 'upload_mvs_media' ) ) {
			return new WP_Error( 'mvs_forbidden', __( 'You do not have permission to create tags.', 'wpmediaverse' ), array( 'status' => 403 ) );
		}
		return true;
	}

	/**
	 * Permissions: admin/moderator only.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return bool|WP_Error
	 */
	public function admin_check( $request ) {
		if ( ! current_user_can( 'moderate_mvs_media' ) ) {
			return new WP_Error( 'mvs_forbidden', __( 'You do not have permission to manage tags.', 'wpmediaverse' ), array( 'status' => 403 ) );
		}
		return true;
	}
}
